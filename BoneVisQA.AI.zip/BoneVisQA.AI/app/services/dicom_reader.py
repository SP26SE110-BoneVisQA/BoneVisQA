﻿"""Load key tags and pixel data from DICOM via pydicom."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pydicom
from pydicom.pixel_data_handlers.util import apply_voi_lut
from PIL import Image


def _normalize_to_uint8(arr: np.ndarray) -> np.ndarray:
    arr = arr.astype(np.float32)
    lo = float(arr.min())
    hi = float(arr.max())
    if hi <= lo:
        return np.zeros_like(arr, dtype=np.uint8)
    arr = (arr - lo) / (hi - lo)
    arr = np.clip(arr * 255.0, 0.0, 255.0)
    return arr.astype(np.uint8)


def read_dicom_tags(path: str | Path) -> dict[str, str | None]:
    """Return PatientID, raw Modality, BodyPartExamined (no ontology mapping)."""
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(str(p))

    ds = pydicom.dcmread(str(p), stop_before_pixels=True)
    pid = ds.get("PatientID")
    mod = ds.get("Modality")
    body = ds.get("BodyPartExamined")

    return {
        "patient_id": (str(pid).strip() if pid is not None else None) or None,
        "modality": (str(mod).strip() if mod is not None else None) or None,
        "body_part_examined": (str(body).strip() if body is not None else None) or None,
    }


def extract_dicom_image(path: str | Path) -> Image.Image:
    """
    Decode DICOM pixel data and return RGB PIL image suitable for vision encoders.

    Handles VOI LUT/windowing, MONOCHROME inversion, and 2D/3D frames.
    """
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(str(p))

    ds = pydicom.dcmread(str(p), stop_before_pixels=False)

    try:
        pixels = ds.pixel_array
    except Exception as ex:
        raise RuntimeError(f"Unable to decode DICOM pixel data: {ex}") from ex

    if pixels.ndim == 3:
        if pixels.shape[-1] in (3, 4):
            first = pixels[..., :3]
            return Image.fromarray(first.astype(np.uint8), mode="RGB")
        pixels = pixels[0]

    if pixels.ndim != 2:
        raise RuntimeError(f"Unsupported DICOM pixel shape: {pixels.shape}")

    try:
        pixels = apply_voi_lut(pixels, ds)
    except Exception:
        pass

    slope = float(ds.get("RescaleSlope", 1.0))
    intercept = float(ds.get("RescaleIntercept", 0.0))
    pixels = pixels.astype(np.float32) * slope + intercept

    if str(ds.get("PhotometricInterpretation", "")).upper() == "MONOCHROME1":
        pixels = np.max(pixels) - pixels

    img_u8 = _normalize_to_uint8(pixels)
    return Image.fromarray(img_u8, mode="L").convert("RGB")
